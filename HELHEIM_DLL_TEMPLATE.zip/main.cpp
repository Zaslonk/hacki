
// HELHEIM - Minimal DLL Template
#include <Windows.h>
#include <iostream>

BOOL APIENTRY DllMain(HMODULE hModule,
                      DWORD  ul_reason_for_call,
                      LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        AllocConsole();
        freopen("CONOUT$", "w", stdout);
        std::cout << "[HELHEIM] DLL Injected Successfully!" << std::endl;
        break;
    case DLL_PROCESS_DETACH:
        std::cout << "[HELHEIM] DLL Unloaded." << std::endl;
        break;
    }
    return TRUE;
}
