// aimbot.hpp
namespace rage { inline bool enabled = false; inline float fov = 0.0f; inline int hitchance = 0; inline bool force_bodyaim = false; }