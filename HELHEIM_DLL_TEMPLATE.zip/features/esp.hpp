// esp.hpp
namespace esp { inline bool boxes = false; inline bool names = false; }