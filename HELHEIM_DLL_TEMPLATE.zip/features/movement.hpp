// movement.hpp
namespace movement { inline bool bhop = false; inline bool autostrafe = false; }