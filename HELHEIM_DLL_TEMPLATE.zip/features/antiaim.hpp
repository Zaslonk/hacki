// antiaim.hpp
namespace antiaim { inline bool enabled = false; }