// triggerbot.hpp
namespace triggerbot { inline bool enabled = false; }