print_log("Lua test: OK")
rage_enable(true)
esp_set_boxes(true)