// theme.hpp
namespace theme { inline void SetDarkTheme() {}; inline void SetNordicTheme() {}; }